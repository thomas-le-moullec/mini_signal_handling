/*
** my_assist.c for my_assist in /home/le-mou_t/rendu/PSU_2015_minitalk/lib
** 
** Made by Thomas LE MOULLEC
** Login   <le-mou_t@epitech.net>
** 
** Started on  Tue Feb  2 23:02:44 2016 Thomas LE MOULLEC
** Last update Tue Feb  2 23:16:08 2016 Thomas LE MOULLEC
*/

#include "mine.h"

char    *my_strcar(char *str, char c)
{
  int   i;
  char  *stock;

  i = 0;
  while (str[i] != '\0')
    i++;
  if ((stock = malloc(sizeof(char) * (i + 2))) == NULL)
    return (NULL);
  i = 0;
  while (str[i] != '\0')
    {
      stock[i] = str[i];
      i++;
    }
  free(str);
  stock[i] = c;
  i++;
  stock[i] = '\0';
  return (stock);
}

int		my_strlen(char *str)
{
  int		i;

  i = 0;
  while (str[i] != '\0')
    i++;
  return (i);
}

void		my_putstr(char *str)
{
  int		i;

  i = 0;
  while (str[i] != '\0')
    {
      my_putchar(str[i]);
      i++;
    }
}
